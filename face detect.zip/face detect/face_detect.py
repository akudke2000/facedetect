import cv2
import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk

class FaceDetectionApp:
    def __init__(self, window):
        self.window = window
        self.window.title("Face Detection App")
        self.window.geometry("300x200")
        self.window.resizable(False, False)

        self.label = tk.Label(window, text="Face Detection", font=("Arial", 16))
        self.label.pack(pady=10)

        self.start_btn = tk.Button(window, text="Start Webcam", command=self.start_camera)
        self.start_btn.pack(pady=10)

        self.stop_btn = tk.Button(window, text="Stop Webcam", command=self.stop_camera, state=tk.DISABLED)
        self.stop_btn.pack(pady=5)

        self.cap = None
        self.running = False

        self.face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

    def start_camera(self):
        self.cap = cv2.VideoCapture(0)
        if not self.cap.isOpened():
            messagebox.showerror("Error", "Unable to access camera")
            return

        self.running = True
        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self.detect_face()

    def detect_face(self):
        if self.running:
            ret, frame = self.cap.read()
            if not ret:
                return

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = self.face_cascade.detectMultiScale(gray, 1.1, 4)

            for (x, y, w, h) in faces:
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

            cv2.imshow("Face Detection", frame)

            # Close window with 'q'
            if cv2.waitKey(1) & 0xFF == ord('q'):
                self.stop_camera()
                return

            self.window.after(10, self.detect_face)

    def stop_camera(self):
        self.running = False
        if self.cap:
            self.cap.release()
        self.start_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)
        cv2.destroyAllWindows()

if __name__ == "__main__":
    root = tk.Tk()
    app = FaceDetectionApp(root)
    root.mainloop()
